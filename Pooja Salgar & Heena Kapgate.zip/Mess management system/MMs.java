package messmanagementsystem;
import java.util.*;
class Database
 {
    int i;
    Scanner sc=new Scanner(System.in);
    String username;
    String userId;
    int password;
    double amountPaid;
    double due;
  
    void checkmenu()
    {
    
    System.out.println("1.Monday\n2.Tuesday\n3.Wednesday\n4.Thrusday\n5.Friday\n6.Saturday");
    System.out.println("Enter your choice");
    int ch=sc.nextInt();
    switch(ch)
    {
        case 1:
        System.out.println("Monday's Menu");
        System.out.println("Breakfast:Upma");
        System.out.println("Lunch:Bhindi,Roti,Rice,dal");
        System.out.println("Dinner:Paneer,Roti ,Rice,dal,Gulabjamun ");
        break;
        
        case 2:
        System.out.println("Tuesday's Menu");
        System.out.println("Breakfast:Puri with chole");
        System.out.println("Lunch:Channa sabji,Salad,Roti,Rice,dal");
        System.out.println("Dinner:Aloo Gobhi,Roti ,Rice,dal,Kheer");
        break;
        
        case 3:
        System.out.println("Wednesday's Menu");
        System.out.println("Breakfast:idli sambhar");
        System.out.println("Lunch:Mix veg,Roti,Rice,dal,curd");
        System.out.println("Dinner:Masoor Dal,Roti ,Rice,dal,Rasgula");
        break;
        
        case 4:
        System.out.println("Thursday's Menu");
        System.out.println("Breakfast:paranthas");
        System.out.println("Lunch:Patta Gobi,Roti,Rice,dal");
        System.out.println("Dinner:Baigan Bharta,Roti ,Rice,dal,Fruit Salat");
        break;
        
        case 5:
        System.out.println("Friday's Menu");
        System.out.println("Breakfast:Poha");
        System.out.println("Lunch:,Roti,Rice,dal");
        System.out.println("Dinner:Paneer,Roti ,Kashmiri Rice,dal,Gulabjamunss");
        break;
        
        case 6:
        System.out.println("Saturday's Menu");
        System.out.println("Breakfast:Pav Bhaji");
        System.out.println("Lunch:Bhindi,Roti,Rice,dal");
        System.out.println("Dinner:Paneer,Roti ,Rice,dal,Gulabjamun");
        break;
        }
    }
    void checkBalance(Database d1[],int i2){
        double totalamount=15000.00;
        System.out.println("Your account details are:");
        
        System.out.println(d1[i2].amountPaid);
	if(d1[i2].amountPaid <=15000)	
	{
            due=totalamount-d1[i2].amountPaid;
            System.out.println("Amount Paid:"+d1[i2].amountPaid);
            System.out.println("due:"+due);
        }
       
        
    }
	void applyforleave()
	{
		System.out.println("HOW MANY DAYS U WANT LEAVE: ");
		int leave = sc.nextInt();
		System.out.println("Your leave is aprroved: ");
		
	}
}

class MMs
    {
   public static Database[] d1=new Database[10];
   public static Database d2=new Database();
   static public void display()
    {
        Scanner sc=new Scanner(System.in);
        int choice;
        do
        {
        System.out.println("1.Checkmenu\n2.Check Balance\n3.Apply for leave");
        System.out.println("Press 0 to exit");
        choice=sc.nextInt();
        switch(choice)
        {
            case 1:
                d2.checkmenu();
                break;
            case 2:
                System.out.println("UserId");
                String userId=sc.next();
                 for(int i=0;i<d1.length;i++)
                {
             if(userId.equalsIgnoreCase(d1[i].userId))
                 
                d2.checkBalance(d1,i);
             
                }
                break;
                
            case 3:
                d2.applyforleave();
                break;
                
            
                
        }
        }while(choice!=0);
        
    }
    public static void main(String[] args)
    {
       // Database[] d1=new Database[10];
       // Database d2=new Database();
      
        Date date=new Date();
        System.out.println(date.toString());
        Scanner sc=new Scanner(System.in);
        System.out.println("\n--------------------------------------------------------------------------------");
        System.out.println("            * Welcome to  Mess *              ");
        System.out.println("--------------------------------------------------------------------------------");
        for (int i = 0; i < 10; i++)
            d1[i] = new Database();
        
        d1[0].userId = "13";
        d1[0].username = "Pooja";
        d1[0].password = 321;
        d1[0].amountPaid=5000.00;
        
        
        d1[1].userId = "14";
        d1[1].username = "Heena";
        d1[1].password = 123;
        d1[1].amountPaid=10000.00;
        
        d1[2].userId = "15";
        d1[2].username = "Payal";
        d1[2].password = 234;
        d1[2].amountPaid=8000.00;
        
        d1[3].userId = "16";
        d1[3].username = "Pratima";
        d1[3].password = 432;
        d1[3].amountPaid=7000.00;
       
   
         System.out.println("Username:");
         String username=sc.next();
         System.out.println("Password:");
         int password=sc.nextInt();
         
         boolean found=false;
         for(int i=0;i<d1.length;i++)
         {
             if(username.equalsIgnoreCase(d1[i].username) && password==(d1[i].password))
             { //display();
                 found=true;
                 display();
             }
             
         }
         if(!found)
         {
             System.out.println("Invalid username or password");
         }
   
    }
}

Output:Sat Nov 28 16:24:15 IST 2020

--------------------------------------------------------------------------------
            * Welcome to  Mess *              
--------------------------------------------------------------------------------
Username:
Pooja
Password:
321
1.Checkmenu
2.Check Balance
3.Apply for leave
Press 0 to exit
1
1.Monday
2.Tuesday
3.Wednesday
4.Thrusday
5.Friday
6.Saturday
Enter your choice
3
Wednesday's Menu
Breakfast:idli sambhar
Lunch:Mix veg,Roti,Rice,dal,curd
Dinner:Masoor Dal,Roti ,Rice,dal,Rasgula
1.Checkmenu
2.Check Balance
3.Apply for leave
Press 0 to exit
2
UserId
13
Your account details are:
5000.0
Amount Paid:5000.0
due:10000.0
1.Checkmenu
2.Check Balance
3.Apply for leave
Press 0 to exit
3
HOW MANY DAYS U WANT LEAVE: 

4
Your leave is aprroved: 
1.Checkmenu
2.Check Balance
3.Apply for leave
Press 0 to exit
0
BUILD SUCCESSFUL (total time: 1 minute 25 seconds)
